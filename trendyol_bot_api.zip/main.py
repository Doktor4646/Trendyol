from fastapi import FastAPI, Request
import uvicorn
import time
import threading
import requests

app = FastAPI()

# Görüntüleme işlemi
def simulate_views(link, adet):
    for i in range(adet):
        try:
            headers = {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"
            }
            requests.get(link, headers=headers, timeout=5)
            print(f"[{i+1}] Ziyaret gönderildi: {link}")
            time.sleep(3)  # Her ziyaret arasında 3 saniye bekle
        except:
            print(f"[{i+1}] ❌ Ziyaret başarısız")

@app.post("/gonder")
async def gonder(request: Request):
    data = await request.json()
    link = data.get("link")
    adet = int(data.get("adet", 1))
    thread = threading.Thread(target=simulate_views, args=(link, adet))
    thread.start()
    return {"status": "ok", "message": f"{adet} görüntüleme başlatıldı."}

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)
